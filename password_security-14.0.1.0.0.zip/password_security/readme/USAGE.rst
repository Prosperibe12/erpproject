Configure using above instructions for each company that should have password
security mandates.
